import React from "react";
import ReactSlider from "./components/reactSlick/slider";
import "bootstrap/dist/css/bootstrap.min.css";

const App = () => {
  return (
    <div className="app">
      <ReactSlider />
    </div>
  );
};

export default App;
